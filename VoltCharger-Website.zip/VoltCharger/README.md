# VoltCharger website starter

This is a responsive front-end prototype for VoltCharger. It includes:
- Charger discovery cards and AC/DC filters
- Charger booking request form
- Host charger enrollment form
- Demo dashboard for bookings and submitted listings
- Responsive layout
- No payment system, checkout, wallet, refunds, commissions or payouts

## Run it
Open `index.html` in a browser, or run a local server from this folder:

```bash
python -m http.server 8000
```

Then visit http://localhost:8000.

## Important: prototype vs production
This version is a working browser prototype. It stores demo chargers and booking requests in this browser's localStorage. It does **not** yet provide real multi-user accounts, secure admin verification, shared cloud bookings, or production-grade double-booking protection.

## Connect Supabase for production
1. Create a Supabase project.
2. Enable Email/Password authentication.
3. Create database tables for profiles, chargers, charger_photos, availability, bookings, and notifications.
4. Add Row Level Security policies so customers can only see/edit their own bookings, hosts can manage only their own chargers, and admins can approve listings.
5. Upload charger photos to a private or public Supabase Storage bucket with appropriate policies.
6. Replace the demo `localStorage` functions in `app.js` with Supabase queries and authenticated user sessions.
7. Enforce booking overlap prevention in a Postgres transaction or exclusion constraint. A browser-only check is not secure enough for production.
8. Add an admin-only review workflow before charger listings become publicly searchable.

## Location and privacy
The map area is currently a visual placeholder. For production, connect Leaflet with OpenStreetMap or another map provider. Keep the precise host address private until a booking is approved; show only an approximate public location.

## No payments
VoltCharger is designed here as a discovery and booking platform only. Prices are display information. Customers and hosts arrange any payment independently outside the platform.
